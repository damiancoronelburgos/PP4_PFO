export const roleMenus = {
  alumno: [
    { to: "inscripcion",   label: "Inscripción a materias" },
    { to: "calificaciones", label: "Calificaciones" },
    { to: "historial",      label: "Historial académico" },
    { to: "notificaciones", label: "Notificaciones" },
  ],
};
